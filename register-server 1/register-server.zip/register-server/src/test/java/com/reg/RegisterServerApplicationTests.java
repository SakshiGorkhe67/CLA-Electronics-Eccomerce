package com.reg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
